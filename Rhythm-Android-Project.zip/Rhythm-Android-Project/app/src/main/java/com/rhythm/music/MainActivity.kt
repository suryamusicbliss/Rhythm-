package com.rhythm.music

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(9, 11, 18)
    private val panel = Color.rgb(20, 24, 36)
    private val accent = Color.rgb(167, 139, 250)
    private val white = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(157, 163, 180)
    private val executor = Executors.newSingleThreadExecutor()
    private val tracks = mutableListOf<Track>()
    private val favourites = linkedSetOf<String>()
    private lateinit var adapter: TrackAdapter
    private lateinit var status: TextView
    private lateinit var titleNow: TextView
    private lateinit var artistNow: TextView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var currentTrack: Track? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        connectPlayer()
        searchTracks("chill")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(22), dp(20), dp(12))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(TextView(this).apply {
            text = "RHYTHM"; textSize = 26f; setTextColor(white); typeface = Typeface.create("sans-serif", Typeface.BOLD)
            letterSpacing = .16f
        })
        brand.addView(TextView(this).apply { text = "YOUR SOUND. YOUR SPACE."; textSize = 9f; setTextColor(muted); letterSpacing = .18f })
        header.addView(brand)
        header.addView(TextView(this).apply {
            text = "●"; textSize = 15f; setTextColor(accent); gravity = Gravity.CENTER
            setBackgroundColor(panel); setPadding(dp(13), dp(10), dp(13), dp(10))
        })
        root.addView(header)
        root.addView(space(18))

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(panel); setPadding(dp(14), dp(2), dp(8), dp(2))
        }
        val query = EditText(this).apply {
            hint = "Search songs, artists, moods"; setHintTextColor(muted); setTextColor(white)
            textSize = 14f; singleLine = true; background = null
            inputType = InputType.TYPE_CLASS_TEXT
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
        }
        val search = Button(this).apply {
            text = "GO"; setTextColor(bg); textSize = 11f; isAllCaps = false
            backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
            setOnClickListener { val q = query.text.toString().trim(); if (q.isNotEmpty()) searchTracks(q) }
        }
        searchRow.addView(query); searchRow.addView(search)
        root.addView(searchRow)
        root.addView(space(20))

        root.addView(TextView(this).apply {
            text = "Discover"; textSize = 22f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Independent music, ready for your next moment."; textSize = 12f; setTextColor(muted)
        })
        root.addView(space(14))

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Chill", "Focus", "Electronic", "Acoustic").forEach { label ->
            val chip = TextView(this).apply {
                text = label; textSize = 11f; setTextColor(if (label == "Chill") bg else muted)
                setPadding(dp(13), dp(9), dp(13), dp(9))
                setBackgroundColor(if (label == "Chill") accent else panel)
                setOnClickListener { searchTracks(label.lowercase()) }
            }
            val lp = LinearLayout.LayoutParams(-2, -2); lp.marginEnd = dp(7); chips.addView(chip, lp)
        }
        root.addView(chips)
        root.addView(space(12))
        status = TextView(this).apply { text = "Loading Jamendo tracks…"; textSize = 12f; setTextColor(muted) }
        root.addView(status)
        val list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        adapter = TrackAdapter(tracks, favourites,
            onPlay = { playTrack(it) },
            onFavourite = { track -> if (!favourites.add(track.id)) favourites.remove(track.id); adapter.notifyDataSetChanged() })
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(panel)
        }
        val now = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        titleNow = TextView(this).apply { text = "Nothing playing"; textSize = 13f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        artistNow = TextView(this).apply { text = "Choose a track to begin"; textSize = 11f; setTextColor(muted); maxLines = 1 }
        now.addView(titleNow); now.addView(artistNow)
        mini.addView(now)
        mini.addView(TextView(this).apply {
            text = "▶"; textSize = 20f; setTextColor(accent); setPadding(dp(12), dp(6), dp(8), dp(6))
            setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        })
        root.addView(mini)
        root.addView(space(5))
        root.addView(TextView(this).apply {
            text = "Developed by Shubham Upadhyay"; textSize = 10f; setTextColor(muted); gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(2))
        })
        setContentView(root)
    }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { controller = controllerFuture?.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun searchTracks(query: String) {
        status.text = "Searching for “$query”…"
        executor.execute {
            try {
                val id = BuildConfig.JAMENDO_CLIENT_ID
                if (id.isBlank()) throw IllegalStateException("Jamendo Client ID missing. Add JAMENDO_CLIENT_ID to GitHub Secrets.")
                val q = URLEncoder.encode(query, "UTF-8")
                val endpoint = "https://api.jamendo.com/v3.0/tracks/?client_id=$id&format=json&limit=30&namesearch=$q&audioformat=mp31&include=musicinfo"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000; readTimeout = 12000; requestMethod = "GET"
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val results = JSONObject(body).optJSONArray("results") ?: throw Exception("No results returned")
                val found = mutableListOf<Track>()
                for (i in 0 until results.length()) {
                    val item = results.getJSONObject(i)
                    val audio = item.optString("audio")
                    if (audio.isNotBlank() && audio != "null") {
                        found.add(Track(
                            item.optString("id"),
                            item.optString("name", "Unknown track"),
                            item.optString("artist_name", "Unknown artist"),
                            audio,
                            item.optString("album_image", "")
                        ))
                    }
                }
                runOnUiThread {
                    tracks.clear(); tracks.addAll(found); adapter.notifyDataSetChanged()
                    status.text = if (found.isEmpty()) "No playable tracks found. Try another search." else "${found.size} tracks • Jamendo catalogue"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = e.message ?: "Could not load tracks. Check your internet connection." }
            }
        }
    }

    private fun playTrack(track: Track) {
        currentTrack = track
        titleNow.text = track.name
        artistNow.text = track.artist
        val c = controller
        if (c == null) {
            status.text = "Player is starting. Tap the track again in a moment."
            return
        }
        c.setMediaItem(MediaItem.fromUri(track.audio))
        c.prepare()
        c.play()
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        executor.shutdown()
        super.onDestroy()
    }
}

private class TrackAdapter(
    private val items: List<Track>,
    private val favourites: MutableSet<String>,
    private val onPlay: (Track) -> Unit,
    private val onFavourite: (Track) -> Unit
) : RecyclerView.Adapter<TrackAdapter.Holder>() {
    class Holder(val row: LinearLayout, val name: TextView, val artist: TextView, val play: TextView, val fav: TextView) : RecyclerView.ViewHolder(row)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val ctx = parent.context
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 13, 10, 13); setBackgroundColor(Color.rgb(20, 24, 36))
        }
        val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        val name = TextView(ctx).apply { textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        val artist = TextView(ctx).apply { textSize = 11f; setTextColor(Color.rgb(157, 163, 180)); maxLines = 1 }
        texts.addView(name); texts.addView(artist)
        val play = TextView(ctx).apply { text = "▶"; textSize = 18f; setTextColor(Color.rgb(167, 139, 250)); setPadding(10, 6, 10, 6) }
        val fav = TextView(ctx).apply { textSize = 19f; setTextColor(Color.rgb(167, 139, 250)); setPadding(8, 6, 8, 6) }
        row.addView(texts); row.addView(play); row.addView(fav)
        return Holder(row, name, artist, play, fav)
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val track = items[position]
        holder.name.text = track.name
        holder.artist.text = track.artist
        holder.fav.text = if (favourites.contains(track.id)) "♥" else "♡"
        holder.play.setOnClickListener { onPlay(track) }
        holder.row.setOnClickListener { onPlay(track) }
        holder.fav.setOnClickListener { onFavourite(track) }
    }
    override fun getItemCount() = items.size
}
