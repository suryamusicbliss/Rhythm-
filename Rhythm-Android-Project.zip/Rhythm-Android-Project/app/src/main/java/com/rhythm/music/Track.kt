package com.rhythm.music

data class Track(
    val id: String,
    val name: String,
    val artist: String,
    val audio: String,
    val image: String
)
